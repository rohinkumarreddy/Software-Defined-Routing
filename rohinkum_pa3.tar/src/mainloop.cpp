#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<mainloop.h>
#include<unistd.h>
#include<cstring>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<strings.h>
#include<string.h>

#include<control_header_lib.h>

#define AUTHOR_STATEMENT "I, rohinkum, have read and understood the course academic integrity policy."

using namespace std;

struct router_topology
{
	uint16_t router_ID;
        uint16_t router_port1;
        uint16_t router_port2;
        uint16_t router_cost;
        char router_IP[INET_ADDRSTRLEN];
};

struct routing_tables
{
	uint16_t router_ID;
	uint16_t padding;
        uint16_t next_hop_ID;
        uint16_t cost;
};

static uint16_t num_routers=0, upd_per_interval=0;

static struct router_topology table[6];
static struct routing_tables r_table[6];

ssize_t recvALL(int sock_index, char *buffer, ssize_t nbytes)
{
    ssize_t bytes = 0;
    bytes = recv(sock_index, buffer, nbytes, 0);

    if(bytes == 0) return -1;
    while(bytes != nbytes)
        bytes += recv(sock_index, buffer+bytes, nbytes-bytes, 0);

    return bytes;
}

ssize_t sendALL(int sock_index, char *buffer, ssize_t nbytes)
{
    ssize_t bytes = 0;
    bytes = send(sock_index, buffer, nbytes, 0);

    if(bytes == 0) return -1;
    while(bytes != nbytes)
        bytes += send(sock_index, buffer+bytes, nbytes-bytes, 0);

    return bytes;
}

char* create_response_header(int sock_index, uint8_t control_code, uint8_t response_code, uint16_t payload_len)
{
	char *buffer;
	//BUILD_BUG_ON(sizeof(struct CONTROL_RESPONSE_HEADER) != CNTRL_RESP_HEADER_SIZE); 
        struct CONTROL_RESPONSE_HEADER *cntrl_resp_header;
    
	struct sockaddr_in addr;
	socklen_t addr_size;

	buffer = (char *) malloc(sizeof(char)*CNTRL_RESP_HEADER_SIZE);

	cntrl_resp_header = (struct CONTROL_RESPONSE_HEADER *) buffer;

	addr_size = sizeof(struct sockaddr_in);
	getpeername(sock_index, (struct sockaddr *)&addr, &addr_size);
	/* Controller IP Address */
	memcpy(&(cntrl_resp_header->controller_ip_addr), &(addr.sin_addr), sizeof(struct in_addr));
	/* Control Code */
	cntrl_resp_header->control_code = control_code;
	/* Response Code */
	cntrl_resp_header->response_code = response_code;
	/* Payload Length */
	cntrl_resp_header->payload_len = htons(payload_len);

	return buffer;
}

void author_response(int sock_index)
{
	uint16_t payload_len, response_len;
	char *cntrl_response_header, *cntrl_response_payload, *cntrl_response;

	payload_len = sizeof(AUTHOR_STATEMENT)-1; // Discount the NULL chararcter
	cntrl_response_payload = (char *) malloc(payload_len);
	memcpy(cntrl_response_payload, AUTHOR_STATEMENT, payload_len);

	cntrl_response_header = create_response_header(sock_index, 0, 0, payload_len);//sock,control_code,response_code,payload_len

	response_len = CNTRL_RESP_HEADER_SIZE+payload_len;
	cntrl_response = (char *) malloc(response_len);
	/* Copy Header */
	memcpy(cntrl_response, cntrl_response_header, CNTRL_RESP_HEADER_SIZE);
	//free(cntrl_response_header);
	/* Copy Payload */
	memcpy(cntrl_response+CNTRL_RESP_HEADER_SIZE, cntrl_response_payload, payload_len);
	//free(cntrl_response_payload);

	sendALL(sock_index, cntrl_response, response_len);

	//free(cntrl_response);
}
void routing_table_response(int );
void init_response(int sock_index, char *cntrl_payload)
{
	uint16_t payload_len=0, response_len=0;
	char *cntrl_response_header, *cntrl_response_payload, *cntrl_response;

	uint16_t num_rout=0,num_routs=0,up_per_int=0,up_per_inter=0,temp=0;int offset=0,num=0;char ip_buffer[INET_ADDRSTRLEN];
	uint32_t temp32=0;

	cntrl_response_header = create_response_header(sock_index, 1, 0, payload_len);//sock,control_code,response_code,payload_len
	response_len = CNTRL_RESP_HEADER_SIZE+payload_len;
	cntrl_response = (char *) malloc(response_len);
	/* Copy Header */
	memcpy(cntrl_response, cntrl_response_header, CNTRL_RESP_HEADER_SIZE);
	//sendALL(sock_index, cntrl_response, response_len);

	memcpy(&num_rout,cntrl_payload+offset,sizeof(num_routs));
	num_routs=ntohs(num_rout);
	num_routers=num_routs;
	cout<<"num of routers is "<<num_routs<<endl;
	offset+=sizeof(num_routs);
	memcpy(&up_per_int,cntrl_payload+offset,sizeof(up_per_inter));
	up_per_inter=ntohs(up_per_int);
	upd_per_interval=up_per_inter;
	cout<<"periodic interval is "<<up_per_inter<<endl;
	offset+=sizeof(up_per_inter);
	while(num_routs>0)
	{
		memcpy(&temp,cntrl_payload+offset,sizeof(temp));
		table[num].router_ID=ntohs(temp);
		r_table[num].router_ID=table[num].router_ID;
		r_table[num].padding=0;
		//cout<<"Router ID is "<<table[num].router_ID<<endl;
		offset+=sizeof(temp);
		memcpy(&temp,cntrl_payload+offset,sizeof(temp));
		table[num].router_port1=ntohs(temp);
		//cout<<"Router port1 is "<<table[num].router_port1<<endl;
		offset+=sizeof(temp);
		memcpy(&temp,cntrl_payload+offset,sizeof(temp));
		table[num].router_port2=ntohs(temp);
		//cout<<"Router port2 is "<<table[num].router_port2<<endl;
		offset+=sizeof(temp);
		memcpy(&temp,cntrl_payload+offset,sizeof(temp));
		table[num].router_cost=ntohs(temp);
		r_table[num].cost=table[num].router_cost;
		if(table[num].router_cost==65535)
		{
			r_table[num].next_hop_ID=65535;
		}
		else 
		{
			r_table[num].next_hop_ID=r_table[num].router_ID;
		}
		//cout<<"Router cost is "<<table[num].router_cost<<endl;

		offset+=sizeof(temp);
		memcpy(&temp32,cntrl_payload+offset,sizeof(temp32));
		//table[0].router_IP=inet_ntop(temp);
	
		struct sockaddr_in ip_addr;
	       	bzero(&ip_addr,sizeof(ip_addr));
	       	ip_addr.sin_family=AF_INET;
		ip_addr.sin_addr.s_addr=temp32;
		//cout<<"Router IP is "<<ip_buffer<<endl;
		inet_ntop(AF_INET,&(ip_addr.sin_addr),ip_buffer,INET_ADDRSTRLEN);
		strcpy(table[num].router_IP,ip_buffer);
		//cout<<"Router IP table[0] is "<<table[num].router_IP<<endl;
		num_routs-=1;num+=1;
		offset+=sizeof(temp32);	
	}//end of while
	//free(cntrl_response_header);
	/* Copy Payload */
	//memcpy(cntrl_response+CNTRL_RESP_HEADER_SIZE, cntrl_response_payload, payload_len);
	//free(cntrl_response_payload);
	//cout<<"memcpy(cntrl_response_payload)"<<endl;
	//sendALL(sock_index, cntrl_response, response_len);--------------------------------
	//free(cntrl_response);
	/*cout<<"Saved Routing table is....\n"<<"Router_ID is "<<r_table[0].router_ID<<"\nPadding "<<r_table[0].padding<<"\nNext_hop_ID "<<r_table[0].next_hop_ID<<"\nCost "<<r_table[0].cost<<endl;
	cout<<"Saved Routing table is....\n"<<"Router_ID is "<<r_table[1].router_ID<<"\nPadding "<<r_table[1].padding<<"\nNext_hop_ID "<<r_table[1].next_hop_ID<<"\nCost "<<r_table[1].cost<<endl;
	cout<<"Saved Routing table is....\n"<<"Router_ID is "<<r_table[2].router_ID<<"\nPadding "<<r_table[2].padding<<"\nNext_hop_ID "<<r_table[2].next_hop_ID<<"\nCost "<<r_table[2].cost<<endl;
	cout<<"Saved Routing table is....\n"<<"Router_ID is "<<r_table[3].router_ID<<"\nPadding "<<r_table[3].padding<<"\nNext_hop_ID "<<r_table[3].next_hop_ID<<"\nCost "<<r_table[3].cost<<endl;
	cout<<"Saved Routing table is....\n"<<"Router_ID is "<<r_table[4].router_ID<<"\nPadding "<<r_table[4].padding<<"\nNext_hop_ID "<<r_table[4].next_hop_ID<<"\nCost "<<r_table[4].cost<<endl;*/
routing_table_response(sock_index);

}

void routing_table_response(int sock_index)
{
	//build packet with routing table response payload
	uint16_t payload_len, response_len,temp=0;int offset=0, num=num_routers, num1=0;
	char *cntrl_response_header, *cntrl_response_payload, *cntrl_response;
	payload_len = sizeof(uint16_t)*4*5; // Discount the NULL chararcter
	//temp = (char*) malloc(sizeof(uint16_t));
	cntrl_response_header = create_response_header(sock_index, 2, 0, payload_len);//sock,control_code,response_code,payload_len
	cntrl_response_payload = (char *) malloc(payload_len);
	//memcpy(temp, &r_table[0].router_ID, sizeof(uint16_t));
	while(num>0)
	{	
		cout<<"router_ID sent is "<<htons(r_table[num1].router_ID)<<endl;
		temp=htons(r_table[num1].router_ID);
		memcpy(cntrl_response_payload+offset, &temp, 2);
		//memcpy(cntrl_response_payload, &r_table[num1].router_ID, sizeof(uint16_t));
		offset+=2;
		cout<<"padding sent is "<<htons(r_table[num1].padding)<<endl;
		temp=htons(r_table[num1].padding);
		memcpy(cntrl_response_payload+offset, &temp, 2);
		//memcpy(cntrl_response_payload+offset, &r_table[num1].padding, sizeof(uint16_t));
		offset+=2;
		cout<<"next_hop_ID sent is "<<htons(r_table[num1].next_hop_ID)<<endl;
		temp=htons(r_table[num1].next_hop_ID);
		memcpy(cntrl_response_payload+offset, &temp, 2);
		//memcpy(cntrl_response_payload+offset, &r_table[num1].next_hop_ID, sizeof(uint16_t));
		offset+=2;
		cout<<"cost sent is "<<htons(r_table[num1].cost)<<endl;
		temp=htons(r_table[num1].cost);
		memcpy(cntrl_response_payload+offset, &temp, 2);
		//memcpy(cntrl_response_payload+offset, &r_table[num1].cost, sizeof(uint16_t));
		offset+=2;
		num-=1;num1+=1;	
	}
	response_len = CNTRL_RESP_HEADER_SIZE+payload_len;
	cntrl_response = (char *) malloc(response_len);
	/* Copy Header */
	memcpy(cntrl_response, cntrl_response_header, CNTRL_RESP_HEADER_SIZE);
	//free(cntrl_response_header);
	/* Copy Payload */
	memcpy(cntrl_response+CNTRL_RESP_HEADER_SIZE, cntrl_response_payload, payload_len);
	//free(cntrl_response_payload);

	sendALL(sock_index, cntrl_response, response_len);
	cout<<"sent routing response to controller"<<endl;

	//free(cntrl_response);
	
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int mainloop(int control_port)
{
	cout<<"\t==========\n\t| ROUTER |\n\t==========\nRunning........\nListening for controller at port "<<control_port<<endl;
	int head_fd=0, control_sock=0;
	fd_set master_list, watch_list;

	//router_socket and data_socket will be initialized after INIT from controller
	FD_ZERO(&master_list);
	FD_ZERO(&watch_list);

	struct sockaddr_in control_addr;
    	socklen_t addrlen = sizeof(control_addr);

	control_sock = socket(AF_INET, SOCK_STREAM, 0);//creating a socket for controller port using TCP

    	if(control_sock < 0)
	{
		cerr<<"socket() failed"<<endl;
	}

	//Make socket re-usable
	//if(setsockopt(control_sock, SOL_SOCKET, SO_REUSEADDR, (int[]){1}, sizeof(int)) < 0){cerr<<"setsockopt() failed"<<endl;}
	int num=1;
    	if(setsockopt(control_sock, SOL_SOCKET, SO_REUSEADDR, &num, sizeof(int))<0)
	{
		cerr<<"setsockopt() failed"<<endl;
	}

	bzero(&control_addr, sizeof(control_addr));
	control_addr.sin_family = AF_INET;
	control_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	control_addr.sin_port = htons(control_port);//assigning control port from command line arguments

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if(bind(control_sock, (struct sockaddr *)&control_addr, sizeof(control_addr)) < 0)
	{
		cerr<<"bind() failed"<<endl;
	}
	//bind and listen
	if(listen(control_sock, 5) < 0)
	{
		cerr<<"listen() failed"<<endl;
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//Register the control socket
	FD_SET(control_sock, &master_list);
	if(head_fd<control_sock)
	{
		head_fd = control_sock;
	}
	int selret=0, sock_index=0, fdaccept=0;
	socklen_t caddr_len=0;

	struct sockaddr_in remote_controller_addr;
	caddr_len = sizeof(remote_controller_addr);

	char *cntrl_header, *cntrl_payload;
	uint8_t control_code;
	uint16_t payload_len;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    	for(;;)
	{
	        watch_list = master_list;
	        selret = select(head_fd+1, &watch_list, NULL, NULL, NULL);
	        if(selret < 0)
		{
			cerr<<"select failed."<<endl;
		}

        	//Loop through file descriptors to check which ones are ready
        	for(sock_index=0; sock_index<=head_fd; sock_index+=1)
		{
			if(FD_ISSET(sock_index, &watch_list))
			{
        	        	//control_socket
        	        	if(sock_index == control_sock)
				{
					fdaccept = accept(sock_index, (struct sockaddr *)&remote_controller_addr, &caddr_len);
					if(fdaccept < 0)
					{
						cerr<<"accept() failed"<<endl;
					}
					//Add to watched socket list
					FD_SET(fdaccept, &master_list);
        	            		if(fdaccept > head_fd)
					{
						head_fd = fdaccept;
					}
        	        	}

/*
        		        //router_socket
        		        else if(sock_index == router_socket)
				{
	      			        //call handler that will call recvfrom() .....
                		}

                		 //data_socket
                		else if(sock_index == data_socket)
				{
	                    		//new_data_conn(sock_index);
                		}

*/


                		//Existing connection
                		else
				{

    					/* Get control header */
					cntrl_header = (char *) malloc(sizeof(char)*CNTRL_HEADER_SIZE);
    					bzero(cntrl_header, CNTRL_HEADER_SIZE);

    					if(recvALL(sock_index, cntrl_header, CNTRL_HEADER_SIZE) < 0)
					{
	        				//remove_control_conn(sock_index);
	        				//free(cntrl_header);
						close(sock_index);
						FD_CLR(sock_index, &master_list);
	        				//return FALSE;
	    				}

    					/* Get control code and payload length from the header */
        				//BUILD_BUG_ON(sizeof(struct CONTROL_HEADER) != CNTRL_HEADER_SIZE);
					if(sizeof(struct CONTROL_HEADER)!=CNTRL_HEADER_SIZE)
					{
						cerr<<"sizeof(struct CONTROL_HEADER) != CNTRL_HEADER_SIZE"<<endl;
					}

        				struct CONTROL_HEADER *header = (struct CONTROL_HEADER *) cntrl_header;
        				control_code = header->control_code;
        				payload_len = ntohs(header->payload_len);
					//free(cntrl_header);
					
					if(payload_len != 0)
					{
	        				cntrl_payload = (char *) malloc(sizeof(char)*payload_len);
	        				bzero(cntrl_payload, payload_len);
        					if(recvALL(sock_index, cntrl_payload, payload_len) < 0)
						{
        				    		//remove_control_conn(sock_index);
        				    		//free(cntrl_payload);
							close(sock_index);
							FD_CLR(sock_index, &master_list);
        				    		//return FALSE;
        					}
    					}

					/* Triage on control_code */
    					switch(control_code)
					{
        					case 0: author_response(sock_index);
         		       				break;
        					case 1: init_response(sock_index, cntrl_payload);
         		       				break;
						case 2: routing_table_response(sock_index);
							break;
            					/*.........
        					....... 
         					......*/
    					}

    					//free(cntrl_payload);
                    			//else if isData(sock_index);
                		}//end of if sock_index == control_sock

            		}
        	}//end of for select
    	}//end of for(;;)
	return 0;
}//end of mainloop
