#ifndef mainLoop // must be unique name in the project
#define mainLoop
//mainloop.h

int mainloop(int );

#endif
